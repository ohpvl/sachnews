package com.ruetgmail.taufiqur.wpnewz.data.preference;

public class PrefKey {
    public static final String APP_PREF_NAME = "wpnews_app";
    public static final String PREF_NAME = "name";
    public static final String PREF_EMAIL = "email";
}